import React from 'react';
import renderer from 'react-test-renderer';
import App from './App';
import data from './data.json';

describe('App snapshot', () => {
    const tasks = [
        { id: "todo-0", name: "Eat", completed: true },
        { id: "todo-1", name: "Sleep", completed: false },
        { id: "todo-2", name: "Repeat", completed: false }
      ]
      test('App snapshot test', () => {
      const component = renderer.create(<App tasks={tasks} />);
      const tree = component.toJSON();
      expect(tree).toMatchSnapshot();
    })
});

const itemNum = 0
describe('Data tests on item '+ itemNum + ' in array', () => {
    test('id contains todo', () => {
        expect(data[itemNum].id).toContain('todo');
    });
    test('object has id property', () => {
        expect(data[itemNum]).toHaveProperty('id');
    });
    test('object has name property', () => {
        expect(data[itemNum]).toHaveProperty('name');;
    });
    test('object has completed property', () => {
        expect(data[itemNum]).toHaveProperty('completed');;
    });
})



