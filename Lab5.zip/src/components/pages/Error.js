import React from 'react';

export default function Error(props) {
    return (
        <div>
            <h1>Oops! Page not found!</h1>
        </div>
    );
}