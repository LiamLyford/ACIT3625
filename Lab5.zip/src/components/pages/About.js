import React from 'react';

export default function About() {
    return (
        <div className="todoapp" style={{ fontFamily: "aria" }}>
            <h1>About PRECIOUS</h1>
            <p>Three Rings for the Elven-kings under the sky,</p>
            <p>Seven for the Dwarf-lords in their halls of stone, </p>
            <p>Nine for Mortal Men doomed to die, </p>
            <p>One for the Dark Lord on his dark throne </p>
            <p>In the Land of Mordor where the Shadows lie. </p>
            <p style={{ fontWeight: "bold" }}>One Ring to rule them all, One Ring to find them, One Ring to bring them all and in the darkness bind them </p>
            <p>In the Land of Mordor where the Shadows lie.</p>
        </div>
    );
}